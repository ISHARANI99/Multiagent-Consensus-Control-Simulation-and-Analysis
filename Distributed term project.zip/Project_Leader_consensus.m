clc; close all; clear all;
N=4;
n=2;
P=[1 0 0 0;
    0 0 0 0;
    0 0 0 0;
    0 0 0 0];
A=[0 1;
    0 0];
B=[0;
    1];
C=[1 0];
D=0;
A_bar=kron(A, eye(N));
B_bar=kron(B, eye(N));
Cf_bar=kron(eye(n), eye(N));
Df_bar=kron(zeros(2,1), eye(N));
C_bar=kron(C, eye(N));
D_bar=kron(D, eye(N));
% %% % Problem 1
% %gamma=1;
% gamma=0.4;
% L=[1 0 0 -1;
%     -1 1 0 0;
%     -1 0 1 0;
%     0 0 -1 1];
% fprintf("Eigen value of L");
% eig(L)
% Tau=[zeros(4) eye(4);
%     -L -gamma.*L];
% fprintf("Eigen value of Tau")
% eig(Tau)

% %% Problem 2
% %gamma=1;
% gamma=0.4;
% L=[0 0 0 0;
%     -1 1 0 0;
%     -1 0 1 0;
%     0 0 -1 1];
% fprintf("Eigen value of L");
% eig(L)
% Tau=[zeros(4) eye(4);
%     -L -gamma.*L];
% fprintf("Eigen value of Tau");
% eig(Tau)

%% Problem 3
%alpha=1;
%alpha=2;
alpha=4;
gamma=10;
L=[0 0 0 0;
    -1 1 0 0;
    -1 0 1 0;
    0 0 -1 1];
fprintf("Eigen value of L");
eig(L)
Tau=[zeros(4) eye(4);
    -L -gamma.*L];
fprintf("Eigen value of Tau");
eig(Tau)
fprintf("Eigen value of Tau_mod");
eig(Tau-kron([0 0; 0 alpha],eye(4)))
