% % t vs x with marker
% for i=1:size(out.tout)
%     plot(out.tout(1:i), out.simout(1:i,1), 'r')
%     hold on
%     plot(out.tout(1:i), out.simout(1:i,2), 'g')
%     plot(out.tout(1:i), out.simout(1:i,3), 'b')
%     plot(out.tout(1:i), out.simout(1:i,4), 'c')
%     plot(out.tout(i), out.simout(i,1), 'o', 'MarkerFaceColor', 'r', 'MarkerSize',3)
%     plot(out.tout(i), out.simout(i,2), 'o', 'MarkerFaceColor', 'g', 'MarkerSize',3)
%     plot(out.tout(i), out.simout(i,3), 'o', 'MarkerFaceColor', 'b', 'MarkerSize',3)
%     plot(out.tout(i), out.simout(i,4), 'o', 'MarkerFaceColor', 'c', 'MarkerSize',3)
%     hold off
%     axis([0 100 0 10])
%     pause(0.1)
% end

% %% 2d plot
% z=zeros(1, length(out.tout));
% pause(3)
% for i=1:length(out.tout)
%     subplot(2, 1, 1)
%     plot(out.simout(1:i,1), z(1:i), 'r')
%     hold on
%     plot(out.simout(1:i,2), z(1:i), 'g')
%     plot(out.simout(1:i,3), z(1:i), 'b')
%     plot(out.simout(1:i,4), z(1:i), 'c')
%     plot(out.simout(i,1), z(i), 'o', 'MarkerFaceColor', 'r', 'MarkerSize',6)
%     plot(out.simout(i,2), z(i), '>', 'MarkerFaceColor', 'g', 'MarkerSize',6)
%     plot(out.simout(i,3), z(i), '*', 'MarkerFaceColor', 'b', 'MarkerSize',6)
%     plot(out.simout(i,4), z(i), 'pentagram', 'MarkerFaceColor', 'c', 'MarkerSize',6)
%     text(out.simout(i,1), z(i)+0.4, '1');
%     text(out.simout(i,2), z(i)+0.7, '2');
%     text(out.simout(i,3), z(i)-0.4, '3');
%     text(out.simout(i,4), z(i)-0.7, '4');
%     text(4,0.8, append('time=',num2str(out.tout(i), 3)));
%     hold off
%     axis([0 5 -1 1])
%     subplot(2, 1, 2)
%      plot(out.tout(1:i), out.simout(1:i,1), 'r')
%     hold on
%     plot(out.tout(1:i), out.simout(1:i,2), 'g')
%     plot(out.tout(1:i), out.simout(1:i,3), 'b')
%     plot(out.tout(1:i), out.simout(1:i,4), 'c')
%     hold off
%     axis([0 100 0 5])
%     pause(0.0001)
% end

%% Normal for printing purpose
Lwidth=1;
     subplot(2, 1, 1)
     plot(out.tout, out.simout(:,1), 'r', LineWidth=Lwidth)
     hold on
     plot(out.tout, out.simout(:,2), 'g', LineWidth=Lwidth)
     plot(out.tout, out.simout(:,3), 'b', LineWidth=Lwidth)
     plot(out.tout, out.simout(:,4), 'c', LineWidth=Lwidth)
     title('Problem 1 Gamma=0.4 with Leader')
     xlabel('Time(in s)')
     ylabel('Position(in m)')
     legend('Agent 1', 'Agent 2', 'Agent 3', 'Agent 4')
     subplot(2, 1, 2)
     plot(out.tout, out.simout(:,5), 'r', LineWidth=Lwidth)
     hold on
     plot(out.tout, out.simout(:,6), 'g', LineWidth=Lwidth)
     plot(out.tout, out.simout(:,7), 'b', LineWidth=Lwidth)
     plot(out.tout, out.simout(:,8), 'c', LineWidth=Lwidth)
     xlabel('Time(in s)')
     ylabel('Velocity(in m/s)')
     legend('Agent 1', 'Agent 2', 'Agent 3', 'Agent 4')